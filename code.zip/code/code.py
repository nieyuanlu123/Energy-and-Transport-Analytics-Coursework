import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler

# 加载数据
data1 = pd.read_excel('data1.xlsx')
data2 = pd.read_csv('data2.csv')

# 数据预处理
data1 = data1.fillna(method='ffill')
data2.dropna(inplace=True)

# 时间转换为分钟
data1['Time(min)'] = data1['Timestamp(ms)'] / 60000


# 速度分析
plt.figure(figsize=(12, 6))
sns.lineplot(data=data1, x='Time(min)', y='Vehicle Speed[km/h]', hue='Trip')
plt.title('Vehicle Speed Analysis Over Time')
plt.xlabel('Time (minutes)')
plt.ylabel('Speed (km/h)')
plt.show()

# 筛选并比较电动车性能
ev_data = data2[data2['PlugType'] == 'Type 2 CCS']
plt.figure(figsize=(12, 6))
sns.barplot(data=ev_data, x='Model', y='Efficiency', palette='viridis')
plt.xticks(rotation=90)
plt.title('Efficiency of Different EV Models')
plt.xlabel('Model')
plt.ylabel('Efficiency (Wh/km)')
plt.show()


# 计算每次行程的距离
data1['Latitude[deg]_shift'] = data1['Latitude[deg]'].shift(1)
data1['Longitude[deg]_shift'] = data1['Longitude[deg]'].shift(1)
data1['distance'] = np.sqrt((data1['Latitude[deg]'] - data1['Latitude[deg]_shift'])**2 + (data1['Longitude[deg]'] - data1['Longitude[deg]_shift'])**2)
total_distance = data1.groupby('Trip')['distance'].sum()

# 显示总距离
plt.figure(figsize=(12, 6))
sns.barplot(x=total_distance.index, y=total_distance.values)
plt.title('Total Distance per Trip')
plt.xlabel('Trip')
plt.ylabel('Distance (degrees)')
plt.show()
