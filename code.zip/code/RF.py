#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import LabelEncoder


# 读取数据
data = pd.read_csv("D:/桌面/work_0419_model/TravelSurveyThess.csv", sep=";", encoding='ISO-8859-7')




# In[11]:


# 选择用于模型的列，并对类别型数据进行编码


# 编码类别型变量
label_encoders = {}
for col in data.columns:
    if data[col].dtype == 'object':
        le = LabelEncoder()
        data[col] = le.fit_transform(data[col].astype(str))
        label_encoders[col] = le


# 如果你想为每种交通模式选择特定的列
modes = ['Walk', 'Car', 'MrC', 'Bus']
# 为每种模式生成特征名称
mode_features = [f"{measure}.{mode}" for mode in modes for measure in ['realTravelTime',  'realTransfer']]

# 其他特征
additional_features = ['Gender','driversLicense', 'HouseHoldSize', 'TripDay', 'Age', 'Unemployed', 'Retired', 'Employed', 'Houseworks', 'Unemployed_other', 'EdHighSchool', 'EdLyceum', 'EdUniversity']

# 合并两个列表
feature_cols = mode_features + additional_features


# 确认目标变量 'mode' 是否存在
if 'mode' not in data.columns:
    print("'mode' column does not exist in the dataset.")
else:
    # 准备特征矩阵和目标向量
    X = data[feature_cols]
    y = data['mode']

    from sklearn.impute import SimpleImputer

# 创建一个填充器，用于填充平均值
imputer = SimpleImputer(strategy='mean')

# 使用平均值填充X中的所有缺失值
X_imputed = imputer.fit_transform(X)

# 重新赋值给X
X = pd.DataFrame(X_imputed, columns=X.columns)




# In[12]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[13]:


# 创建随机森林模型
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)

# 训练模型
rf_model.fit(X_train, y_train)


# In[14]:


# 预测测试集
y_pred = rf_model.predict(X_test)

# 评估模型
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))


# In[20]:


from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

# 计算混淆矩阵
cm = confusion_matrix(y_test, y_pred)

# 使用seaborn来创建热图
sns.heatmap(cm, annot=True, fmt='d')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')  # 添加标题
plt.show()


# In[19]:


import matplotlib.pyplot as plt
import numpy as np

# 获取特征重要性
importances = rf_model.feature_importances_

# 将特征名称和其重要性分数配对
feature_names = np.array(feature_cols)  # 确保feature_cols包含了所有你用于模型的特征名称
feature_importances = sorted(zip(importances, feature_names), reverse=True)

# 分解成两个列表
sorted_importances = [imp[0] for imp in feature_importances]
sorted_features = [imp[1] for imp in feature_importances]

# 创建条形图
plt.figure(figsize=(5, 4))
plt.barh(sorted_features, sorted_importances, color='turquoise')
plt.xlabel('Importance')
plt.ylabel('Feature')
plt.title('Feature Importance')
plt.gca().invert_yaxis()  # 反转y轴方向，使得重要性最高的特征位于顶部
plt.show()


