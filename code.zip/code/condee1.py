import pandas as pd
import numpy as np
from patsy.highlevel import dmatrices
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.discrete.discrete_model import MNLogit

TripsForR = pd.read_csv('TripsForR.csv')
PopulationNewSample = pd.read_csv('PopulationNewSample.csv')
Prod_attraction_10 = pd.read_csv('Prod_attraction_10.csv')
DistancesTT = pd.read_csv('skim_TTC_DIS10.csv', header=None)

# 尝试使用ISO-8859-1编码读取TravelSurveyThess.csv文件，如果失败则使用Windows-1252编码
try:
    TravelSurveyThess = pd.read_csv('TravelSurveyThess.csv', delimiter=';', encoding='ISO-8859-1')
except UnicodeDecodeError:
    TravelSurveyThess = pd.read_csv('TravelSurveyThess.csv', delimiter=';', encoding='Windows-1252')

# 清除数据框列名中的空白
TripsForR.columns = TripsForR.columns.str.strip()
PopulationNewSample.columns = PopulationNewSample.columns.str.strip()
Prod_attraction_10.columns = Prod_attraction_10.columns.str.strip()
TravelSurveyThess.columns = TravelSurveyThess.columns.str.strip()

# 替换距离矩阵中的0为一个非常大的数
DistancesTT.replace(0, 9999999, inplace=True)

mm_NoIntrazonal = TripsForR[TripsForR['Origin'] != TripsForR['Destination']]
mm_NoIntrazonal2 = mm_NoIntrazonal[(mm_NoIntrazonal['DurationMinutes'] > 10) & (mm_NoIntrazonal['Mode'] == 5)]
mm_NoIntrazonal3 = mm_NoIntrazonal[mm_NoIntrazonal['Mode'] != 5]
mm_Final = pd.concat([mm_NoIntrazonal2, mm_NoIntrazonal3])

mm_Male_Active = mm_Final[(mm_Final['Gender'] == 1) & (mm_Final['WorkState'] == 1)]
mm_Male_Non_Active = mm_Final[(mm_Final['Gender'] == 1) & (mm_Final['WorkState'] == 2)]
mm_Female_Active = mm_Final[(mm_Final['Gender'] == 2) & (mm_Final['WorkState'] == 1)]
mm_Female_Non_Active = mm_Final[(mm_Final['Gender'] == 2) & (mm_Final['WorkState'] == 2)]


# 筛选符合条件的行程数据
HBW_Male_Active = mm_Male_Active[(mm_Male_Active['StartActivity'] == 'Home') & (mm_Male_Active['EndActivity'] == 'Work')]
WBH_Male_Active = mm_Male_Active[(mm_Male_Active['StartActivity'] == 'Work') & (mm_Male_Active['EndActivity'] == 'Home')]

HBW_Male_Non_Active = mm_Male_Non_Active[(mm_Male_Non_Active['StartActivity'] == 'Home') & (mm_Male_Non_Active['EndActivity'] == 'Work')]
WBH_Male_Non_Active = mm_Male_Non_Active[(mm_Male_Non_Active['StartActivity'] == 'Work') & (mm_Male_Non_Active['EndActivity'] == 'Home')]

HBW_Female_Active = mm_Female_Active[(mm_Female_Active['StartActivity'] == 'Home') & (mm_Female_Active['EndActivity'] == 'Work')]
WBH_Female_Active = mm_Female_Active[(mm_Female_Active['StartActivity'] == 'Work') & (mm_Female_Active['EndActivity'] == 'Home')]

HBW_Female_Non_Active = mm_Female_Non_Active[(mm_Female_Non_Active['StartActivity'] == 'Home') & (mm_Female_Non_Active['EndActivity'] == 'Work')]
WBH_Female_Non_Active = mm_Female_Non_Active[(mm_Female_Non_Active['StartActivity'] == 'Work') & (mm_Female_Non_Active['EndActivity'] == 'Home')]


PerZoneHBW_Female_Active = HBW_Female_Active.groupby('Origin').size().reset_index(name='ProdHBWFemaleActive')
PerZoneWBH_Female_Active = WBH_Female_Active.groupby('Destination').size().reset_index(name='ProdWBHFemaleActive')

PerZoneHBW_Female_Active.rename(columns={'Origin': 'Zones'}, inplace=True)
PerZoneWBH_Female_Active.rename(columns={'Destination': 'Zones'}, inplace=True)

Female_Active_Sample = PopulationNewSample[['Zones', 'WomenActive']]

# 合并数据框
total_Female_Active = PerZoneHBW_Female_Active.merge(PerZoneWBH_Female_Active, on='Zones')
total_Female_Active = total_Female_Active.merge(Female_Active_Sample, on='Zones')
total_Female_Active['totalTrips'] = total_Female_Active['ProdHBWFemaleActive'] + total_Female_Active['ProdWBHFemaleActive']

# 线性回归
X = total_Female_Active[['WomenActive']]
y = total_Female_Active['totalTrips']
model = LinearRegression().fit(X, y)

# 可视化
sns.scatterplot(data=total_Female_Active, x='WomenActive', y='totalTrips')
plt.title('Relationship between Women Active and Total Trips')
plt.show()

# 绘制拟合线
plt.figure(figsize=(8, 6))
sns.scatterplot(data=total_Female_Active, x='WomenActive', y='totalTrips')
plt.plot(total_Female_Active['WomenActive'], model.predict(X), color='red', linewidth=2)
plt.title('Relationship between Women Active and Total Trips with Linear Regression Line')
plt.xlabel('Women Active')
plt.ylabel('Total Trips')
plt.show()

# 绘制残差图
residuals = y - model.predict(X)
plt.figure(figsize=(8, 6))
sns.scatterplot(x=total_Female_Active['WomenActive'], y=residuals)
plt.axhline(y=0, color='r', linestyle='--')
plt.title('Residual Plot')
plt.xlabel('Women Active')
plt.ylabel('Residuals')
plt.show()

# 计算评价指标
from sklearn.metrics import r2_score, mean_squared_error

r_squared = r2_score(y, model.predict(X))
mse = mean_squared_error(y, model.predict(X))

print("R^2 Score:", r_squared)
print("Mean Squared Error:", mse)
