import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# # 载入数据集1
# data1 = pd.read_excel('data1.xlsx')
#
# # 将Timestamp转换为更容易理解的时间格式
# data1['Timestamp'] = pd.to_datetime(data1['Timestamp(ms)'], unit='ms')
#
# # 去除含有NaN值的列
# data1_clean = data1.dropna(axis=1, how='all')
#
# # 车速与发动机转速的关系可视化
# plt.figure(figsize=(10, 6))
# sns.scatterplot(x='Vehicle Speed[km/h]', y='Engine RPM[RPM]', data=data1_clean)
# plt.title('Vehicle Speed vs Engine RPM')
# plt.xlabel('Vehicle Speed (km/h)')
# plt.ylabel('Engine RPM')
# plt.show()


# 载入数据集2
data2 = pd.read_csv('data2.csv')

# 描述性统计
brand_stats = data2.groupby('Brand').agg({'PriceEuro':'mean', 'Accel':'mean'}).reset_index()

# 价格与续航能力的关系可视化
plt.figure(figsize=(10, 6))
sns.scatterplot(x='PriceEuro', y='Range', hue='Brand', data=data2)
plt.title('Price vs Range for Different Brands')
plt.xlabel('Price (Euro)')
plt.ylabel('Range (km)')
plt.legend(loc='upper right')
plt.show()


