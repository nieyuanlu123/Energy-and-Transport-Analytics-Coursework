import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# 步骤 1: 数据导入和预处理
def load_and_preprocess():
    population_df = pd.read_csv('PopulationNewSample.csv')
    prod_attraction_df = pd.read_csv('Prod_attraction_10.csv')
    skim_TTC_df = pd.read_csv('skim_TTC_DIS10.csv')
    thessaloniki_df = pd.read_csv('thessalonikiclean.csv')
    trips_df = pd.read_csv('TripsForR.csv')
    data2_df = pd.read_csv('data2.csv')

    # 去除所有列名的前后空格
    population_df.columns = population_df.columns.str.strip()
    prod_attraction_df.columns = prod_attraction_df.columns.str.strip()
    skim_TTC_df.columns = skim_TTC_df.columns.str.strip()
    thessaloniki_df.columns = thessaloniki_df.columns.str.strip()
    trips_df.columns = trips_df.columns.str.strip()
    data2_df.columns = data2_df.columns.str.strip()
    return population_df, prod_attraction_df, skim_TTC_df, thessaloniki_df, trips_df, data2_df

# 探索性数据分析（EDA）
def eda_more(population_df, prod_attraction_df, thessaloniki_df, data2_df):
    # 性别与活跃状态的堆叠条形图
    population_df.groupby('Zones').sum().plot(kind='bar', stacked=True)
    plt.xlabel('Zones')
    plt.ylabel('Population')
    plt.title('Population Distribution by Zones and Activity')
    plt.show()

    # 生产与吸引力关系的散点图和回归线
    plt.scatter(prod_attraction_df['PRODUCTION'], prod_attraction_df['ATTRACTION'])
    reg = LinearRegression().fit(prod_attraction_df[['PRODUCTION']], prod_attraction_df['ATTRACTION'])
    prod_range = np.linspace(prod_attraction_df['PRODUCTION'].min(), prod_attraction_df['PRODUCTION'].max(), 100)
    plt.plot(prod_range, reg.predict(prod_range.reshape(-1, 1)), color='red', linewidth=2)
    plt.xlabel('Production')
    plt.ylabel('Attraction')
    plt.title('Production vs Attraction with Regression Line')
    plt.show()

    # 不同区域的通勤模式分布的饼图
    mode_counts = thessaloniki_df['mode'].value_counts()
    plt.pie(mode_counts, labels=mode_counts.index, autopct='%1.1f%%')
    plt.title('Commuting Mode Distribution')
    plt.show()

    # 车辆速度与发动机转速的关系
    plt.scatter(data2_df['TopSpeed'], data2_df['Accel'])
    plt.xlabel('Top Speed (km/h)')
    plt.ylabel('Acceleration (sec to 100 km/h)')
    plt.title('Vehicle Speed vs Acceleration')
    plt.show()

    # 车辆加速度分布的直方图
    data2_df['Accel'] = data2_df['Accel'].str.replace(' sec', '').astype(float)
    plt.hist(data2_df['Accel'], bins=20, color='green', alpha=0.7)
    plt.xlabel('Acceleration (sec to 100 km/h)')
    plt.ylabel('Frequency')
    plt.title('Distribution of Vehicle Acceleration')
    plt.show()

    # 车辆品牌和型号的树形图
    tree_counts = data2_df['Brand'].value_counts()
    plt.barh(tree_counts.index, tree_counts)
    plt.xlabel('Count')
    plt.ylabel('Brand')
    plt.title('Tree Map of Vehicle Brands')
    plt.show()

# 建立预测模型
def build_predictive_models(prod_attraction_df):
    # 准备数据
    X = prod_attraction_df[['PRODUCTION']]
    y = prod_attraction_df['ATTRACTION']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 线性回归模型
    linear_model = LinearRegression()
    linear_model.fit(X_train, y_train)
    y_pred_linear = linear_model.predict(X_test)
    mse_linear = mean_squared_error(y_test, y_pred_linear)

    # 岭回归模型
    ridge_model = Ridge(alpha=1.0)
    ridge_model.fit(X_train, y_train)
    y_pred_ridge = ridge_model.predict(X_test)
    mse_ridge = mean_squared_error(y_test, y_pred_ridge)

    # 决策树回归模型
    tree_model = DecisionTreeRegressor(random_state=42)
    tree_model.fit(X_train, y_train)
    y_pred_tree = tree_model.predict(X_test)
    mse_tree = mean_squared_error(y_test, y_pred_tree)

    # 绘制结果
    plt.figure(figsize=(18, 6))
    plt.subplot(131)
    plt.scatter(X_test, y_test, color='black')
    plt.plot(X_test, y_pred_linear, color='blue', linewidth=2)
    plt.title('Linear Regression\nMSE: {:.2f}'.format(mse_linear))
    plt.xlabel('Production')
    plt.ylabel('Attraction')

    plt.subplot(132)
    plt.scatter(X_test, y_test, color='black')
    plt.plot(X_test, y_pred_ridge, color='green', linewidth=2)
    plt.title('Ridge Regression\nMSE: {:.2f}'.format(mse_ridge))
    plt.xlabel('Production')
    plt.ylabel('Attraction')

    plt.subplot(133)
    plt.scatter(X_test, y_test, color='black')
    plt.scatter(X_test, y_pred_tree, color='red')
    plt.title('Decision Tree Regression\nMSE: {:.2f}'.format(mse_tree))
    plt.xlabel('Production')
    plt.ylabel('Attraction')

    plt.tight_layout()
    plt.show()

    return {
        'Linear Regression': mse_linear,
        'Ridge Regression': mse_ridge,
        'Decision Tree Regression': mse_tree
    }

# 聚类分析
def cluster_analysis(prod_attraction_df):
    kmeans = KMeans(n_clusters=3)
    prod_attraction_df['Cluster'] = kmeans.fit_predict(prod_attraction_df[['PRODUCTION', 'ATTRACTION']])
    plt.scatter(prod_attraction_df['PRODUCTION'], prod_attraction_df['ATTRACTION'], c=prod_attraction_df['Cluster'])
    plt.xlabel('Production')
    plt.ylabel('Attraction')
    plt.title('K-Means Clustering')
    plt.show()
    return kmeans

# 修改后的评估干预措施
def evaluate_interventions_modified(thessaloniki_df, car_to_bus_ratio):
    car_users = thessaloniki_df[thessaloniki_df['mode'] == 'Car']
    bus_users = thessaloniki_df[thessaloniki_df['mode'] == 'Bus']
    num_car_to_bus = int(len(car_users) * car_to_bus_ratio)

    # 随机选择这部分汽车通勤者并改变他们的通勤方式
    car_users_to_change = car_users.sample(n=num_car_to_bus)
    car_users = car_users.drop(car_users_to_change.index)
    car_users_to_change['mode'] = 'Bus'

    bus_users = pd.concat([bus_users, car_users_to_change])

    # 公交通勤时间减少20%以吸引更多乘客
    bus_users['realTravelTime.Bus'] *= 0.8

    return car_users, bus_users

# 优化模型
def optimize_model(car_users, bus_users):
    total_commute_time_car = car_users['realTravelTime.Car'].sum() * 2
    total_commute_time_bus = bus_users['realTravelTime.Bus'].sum()
    total_commute_time = total_commute_time_car + total_commute_time_bus
    return total_commute_time

# 结果可视化
def visualize_results_updated(car_users, bus_users, prod_attraction_df, kmeans, title_suffix):
    # 可视化聚类结果
    plt.figure(figsize=(12, 6))
    plt.scatter(prod_attraction_df['PRODUCTION'], prod_attraction_df['ATTRACTION'], c=kmeans.labels_, cmap='viridis')
    plt.xlabel('Production')
    plt.ylabel('Attraction')
    plt.title(f'Production and Attraction Clusters - {title_suffix}')
    plt.colorbar()
    plt.show()

    # 可视化通勤分布
    plt.figure(figsize=(14, 7))
    plt.subplot(1, 2, 1)
    plt.bar(['Car', 'Bus'], [len(car_users), len(bus_users)])
    plt.title('Commuter Distribution Before Intervention')

    plt.subplot(1, 2, 2)
    plt.bar(['Car', 'Bus'], [len(car_users), len(bus_users)])
    plt.title('Commuter Distribution After Intervention')
    plt.show()

def main():
    # 加载和预处理数据
    population_df, prod_attraction_df, skim_TTC_df, thessaloniki_df, trips_df, data2_df = load_and_preprocess()

    # 执行EDA
    eda_more(population_df, prod_attraction_df, thessaloniki_df, data2_df)

    # 聚类分析
    kmeans = cluster_analysis(prod_attraction_df)

    # 构建和评估预测模型
    model_mse = build_predictive_models(prod_attraction_df)
    for model_name, mse in model_mse.items():
        print(f"{model_name} MSE: {mse}")


    ratios = [0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5]
    results = []

    for ratio in ratios:
        # 评估干预措施并优化模型
        car_users, bus_users = evaluate_interventions_modified(thessaloniki_df, ratio)
        total_commute_time = optimize_model(car_users, bus_users)
        results.append(total_commute_time)
        print(f'Total commute time with car_to_bus_ratio {ratio}: {total_commute_time}')

        # 可视化结果
        visualize_results_updated(car_users, bus_users, prod_attraction_df, kmeans, f'Ratio {ratio}')

    # 在一张图上可视化所有结果
    plt.figure(figsize=(10, 5))
    plt.plot(ratios, results, marker='o')
    plt.xlabel('Car to Bus Ratio')
    plt.ylabel('Total Commute Time')
    plt.title('Effect of Car to Bus Ratio on Total Commute Time')
    plt.grid(True)
    plt.show()

if __name__ == '__main__':
    main()
