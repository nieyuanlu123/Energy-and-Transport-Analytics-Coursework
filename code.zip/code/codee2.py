import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

# 定义一个函数来读取CSV文件并清理列名中的空格
def read_csv_remove_spaces(filename):
    # 读取CSV文件，跳过字段开始的空格
    df = pd.read_csv(filename, skipinitialspace=True, engine='python')
    # 去除列名中的所有空格
    df.columns = df.columns.str.replace(' ', '')
    return df

# 使用定义的函数读取数据
trips = read_csv_remove_spaces("TripsForR.csv")
population = read_csv_remove_spaces("PopulationNewSample.csv")
prod_attraction = read_csv_remove_spaces("Prod_attraction_10.csv")
distances = pd.read_csv("skim_TTC_DIS10.csv", header=None, skipinitialspace=True, engine='python')

# 示范输出，查看列名是否正确处理
print(trips.columns)
print(population.columns)
print(prod_attraction.columns)

# 数据过滤：移除起点终点相同的行程
mm_NoIntrazonal = trips[trips['Origin'] != trips['Destination']]

# 过滤行程时间大于10分钟且模式为5的数据
mm_NoIntrazonal2 = mm_NoIntrazonal[(mm_NoIntrazonal['DurationMinutes'] > 10) & (mm_NoIntrazonal['Mode'] == 5)]

# 过滤模式不为5的数据
mm_NoIntrazonal3 = mm_NoIntrazonal[mm_NoIntrazonal['Mode'] != 5]

# 合并数据集
mm_Final = pd.concat([mm_NoIntrazonal2, mm_NoIntrazonal3])

# 数据分类
mm_Male_Active = mm_Final[(mm_Final['Gender'] == 1) & (mm_Final['WorkState'] == 1)]
mm_Female_Active = mm_Final[(mm_Final['Gender'] == 2) & (mm_Final['WorkState'] == 1)]

# 根据起始和结束活动分组并统计数量
def group_by_activity(df, start_act, end_act):
    return df[(df['StartActivity'] == start_act) & (df['EndActivity'] == end_act)]

# 活动分组
HBW_Male_Active = group_by_activity(mm_Male_Active, "Home", "Work")
WBH_Female_Active = group_by_activity(mm_Female_Active, "Work", "Home")

# 对活跃女性按起始活动分组
PerZone_HBW_Female_Active = HBW_Male_Active.groupby('Origin').size().reset_index(name='ProdHBWFemaleActive')
PerZone_HBW_Female_Active.rename(columns={'Origin': 'Zones'}, inplace=True)

PerZone_WBH_Female_Active = WBH_Female_Active.groupby('Destination').size().reset_index(name='ProdWBHFemaleActive')
PerZone_WBH_Female_Active.rename(columns={'Destination': 'Zones'}, inplace=True)

# 合并与样本数据
Female_Active_Sample = population[['Zones', 'WomenActive']]
total_Female_Active = pd.merge(PerZone_HBW_Female_Active, PerZone_WBH_Female_Active, on='Zones')
total_Female_Active = pd.merge(total_Female_Active, Female_Active_Sample, on='Zones')

from statsmodels.formula.api import ols

# 线性模型分析
total_Female_Active['TotalTrips'] = total_Female_Active['ProdHBWFemaleActive'] + total_Female_Active['ProdWBHFemaleActive']
model = ols("TotalTrips ~ WomenActive - 1", data=total_Female_Active).fit()
print(model.summary())

# 将距离转换为摩擦值，将零替换为无穷大
distances.replace(0, np.inf, inplace=True)
friction = np.exp(-0.035 * distances.values)  # 确保它是一个NumPy数组

# 计算初始吸引力和产量调整
prod_attraction['ATTRACTION'] = np.round(prod_attraction['ATTRACTION'] * prod_attraction['PRODUCTION'].sum() / prod_attraction['ATTRACTION'].sum())

# 确保使用.to_numpy()确保转换为numpy数组
k_d = (prod_attraction['ATTRACTION'] / friction.sum(axis=1)).to_numpy()
k_o = prod_attraction['PRODUCTION'].to_numpy()

# 迭代比例拟合，展示迭代过程中k_d和k_o的变化
k_ds = []
k_os = []
for _ in range(5):
    estimated_OD = (k_d[:, None] * k_o) * friction  # 计算预测的OD矩阵
    k_d = (prod_attraction['ATTRACTION'] / estimated_OD.sum(axis=1)).to_numpy()
    k_o = (prod_attraction['PRODUCTION'] / estimated_OD.sum(axis=0)).to_numpy()
    k_ds.append(k_d.copy())  # 保存每次迭代后的k_d值
    k_os.append(k_o.copy())  # 保存每次迭代后的k_o值

# 可视化部分
# 使用matplotlib和seaborn绘制图表

# 性别和工作状态的关系图
plt.figure(figsize=(10, 6))
sns.countplot(x='Gender', hue='WorkState', data=mm_Final)
plt.title('Distribution of Gender and Work State')
plt.xlabel('Gender (1=Male, 2=Female)')
plt.ylabel('Count')
plt.legend(title='Work State')
plt.show()

# 行程时间分布图
plt.figure(figsize=(10, 6))
sns.histplot(mm_Final['DurationMinutes'], kde=True)
plt.title('Distribution of Trip Duration')
plt.xlabel('Trip Duration (minutes)')
plt.ylabel('Frequency')
plt.show()

# 迭代中k_d值的变化
plt.figure(figsize=(10, 6))
for i, kd in enumerate(k_ds):
    plt.plot(kd, label=f'Iteration {i+1}')
plt.title('Change of k_d Values during Iterations')
plt.xlabel('Index')
plt.ylabel('k_d Value')
plt.legend()
plt.show()

# 迭代中k_o值的变化
plt.figure(figsize=(10, 6))
for i, ko in enumerate(k_os):
    plt.plot(ko, label=f'Iteration {i+1}')
plt.title('Change of k_o Values during Iterations')
plt.xlabel('Index')
plt.ylabel('k_o Value')
plt.legend()
plt.show()

# 摩擦值矩阵的热图
plt.figure(figsize=(10, 8))
sns.heatmap(friction, annot=False, cmap='coolwarm')
plt.title('Heatmap of Friction Matrix')
plt.xlabel('Destination Zone Index')
plt.ylabel('Origin Zone Index')
plt.show()

# # 线性模型分析结果的散点图和拟合线
# plt.figure(figsize=(10, 6))
# sns.regplot(x='WomenActive', y='TotalTriaps', data=total_Female_Active, scatter_kws={'s':50}, line_kws={'color':'red'})
# plt.title('总行程数与活跃女性数量的回归分析')
# plt.xlabel('活跃女性数量')
# plt.ylabel('总行程数')
# plt.show()

